<?php

$server_name = "localhost";
$username = "root";
$password = "";
$dbname = "content";

$connection = mysqli_connect($server_name, $username, $password, $dbname);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// echo "Connection successful";
?>