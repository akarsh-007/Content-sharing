<?php
include 'dbconnection.php';

$title = $_POST["title"];
$write = $_POST["content"];
$url = $_POST["url"];

$query = mysqli_query($connection, "INSERT INTO `articles` (`wrte`, `imgsrc`, `title`) VALUES ('$write', '$url', '$title');");

$_SESSION['user'] = $title;
header("Location: /content/HomePage/home.php");
