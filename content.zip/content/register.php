<?php

include 'dbconnection.php';

$name = $_POST["name"];
$password = $_POST["pass"];
$gender = $_POST["gender"];
$email = $_POST["mail"];
$phone = $_POST["phone"];
$usn = $_POST["usn"];

$query = "insert into `user` (`name`,`password`, `usn`, `gender`,`mail`,`phone_no`) values('$name','$password ', '$email',' $gender',' $email',' $phone ')";

if ($connection->query($query)) {
    echo "Register successful, <a href='login.html'>click here</a> to Login";
} else {
    echo 'Error: ' . $query . '<br>' . $connection->error;
}
