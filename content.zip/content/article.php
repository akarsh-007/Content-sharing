<?php
echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport'content='width=device-width, initial-scale=1.0'>
        <title>Document</title>
    </head>
    <body>
        ";
include 'dbconnection.php';

$id = $_GET['id'];

$sql = "select * from articles where id = '$id'";

$result = $connection->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<h1>" . $row["title"] . "</h1>";
        echo "<img style='height: 200px' src='" . $row["imgsrc"] . "'>";
        echo "<div>".$row["wrte"]."</div>";
    }
}else{
    echo "<h3>Article not found with id ".$id."</h3>";  
}

echo "</body>
    </html>";
