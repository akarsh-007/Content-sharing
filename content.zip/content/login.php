<?php

if (isset($_SESSION['id']))
    session_destroy();
session_start();
include 'dbconnection.php';

$name = $_POST["name"];
$password = $_POST["pass"];

$query = mysqli_query($connection, "select id,name,password from user where usn='$name' and password='$password'");
$count = mysqli_num_rows($query);

$sql1 = "SELECT id from user where `user`.`usn` = '$name'";
$result = $connection->query($sql1);
$id = "";
echo $result->num_rows;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $id = $row['id'];
        $_SESSION['id'] = $id;
    }
}
echo $_SESSION['id'];
if ($count == 1) {
    $_SESSION['user'] = $name;
    header("Location: /content/HomePage/home.php");
} else {
    echo $connection->error;
}
