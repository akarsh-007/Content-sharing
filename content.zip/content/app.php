<?php
    session_start();
    include 'dbconnection.php';
    
    $name = $_POST["name"];
    $password = $_POST["pass"];
    
    
    $query = mysqli_query($connection, "select id,name,password from customer where name='$name' and password='$password'");
    $count = mysqli_num_rows($query);
    
    $sql1 = "SELECT id from customer where name = '$name'";
    $result = $connection->query($sql1);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $id = $row['id'];
            $_SESSION['id'] = $id;
        }
    }
    
    if ($count == 1) {
    
        $_SESSION['user'] = $name;
        header("Location: items.php");
    } else {
        echo $connection->error;
    }
