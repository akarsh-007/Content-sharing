<?php

echo "<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Content</title>
    <link rel='stylesheet' href='../style.css'>
    <link rel='stylesheet' href='home.css'>
    <style>
    body {
    overflow-y: scroll;
}
.button{
    display: inline-block;
    text-decoration: none;
    margin: -100px;
    color: #fbfcfd;
    padding: 10px 25px;
    background: transparent;
    border: 1px solid #fff;
    border-radius: 20px;
    outline: none;
    cursor: pointer;
}

    .article-cards {
    padding: 1rem 2rem;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}
    .article-desc {
        overflow: hidden;
        text-overflow: ellipsis;
        width: 90%;
        margin: 10px 0;
        height: 2rem;
        line-height: 1.1rem;
    }
    .article-card {
    height: 3.3rem;
    overflow: hidden;
    transition: height 300ms ease-out;
    cursor: pointer;
    }
    .article-card:hover {
        height: 20rem;
}
    .article-card .article-img{
        width: 100%;
        max-height: 10rem;
        margin-top: 10px;
    }

    .article-actions {
        display: flex;
        justify-content: space-between;
        width: 100%;
    }
    .article-actions .heart-img {
    display: flex;
    align-items: center;
        width: 30px;
        margin: 6px;
        cursor: pointer;
    }
.article-actions .heart-img span {
    font-size: 12px;
}
    .delete-img {
        height: 20px;
        width: 20px;
        margin-top: 7px;
        margin-right: 3px;
        cursor: pointer;
    }
    .delete-img img {
        height: 100%;
        width: 100%;
    }
    
.log{
    float:right;
    border: 1px solid blue;
    padding: 10px;
    color: white;
    background-color: blue;
    text-decoration: none;
   }
   .login{
 float:right;
    border: 1px solid blue;
    padding: 10px;
    color: white;
    background-color: blue;
    text-decoration: none;
}
  .reg{
  float:right;
    border: 1px solid blue;
    padding: 10px;
    color: white;
    background-color: blue;
    text-decoration: none;
    }

    .article-card .article-img{
        width: 100%;
        margin-top: 10px;
    }
    @media only screen and (max-width: 721px){
    .article-card {
    height: 20rem;
    overflow: hidden;
    transition: height 0s ease-out;
    cursor: pointer;
    }
    
}
    
    </style>
</head>

<body>
    <div class='square'>
        <a class='plus' href='../WriteArticle/write-article.html'>+</a>  
    </div>
   
    <div class='article-cards'>
    <div>
    <a href='http://localhost/content/logout/logout.html' class='button'>logout</a>
    </div>
    ";

include '../dbconnection.php';

$sql = "select * from articles";

$result = $connection->query($sql);

session_start();

if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    include '../dbconnection.php';
    $sql = "DELETE FROM `articles` WHERE `articles`.`id` = $id";
    $result1 = $connection->query($sql);
    if ($result1)
        header("Location: /content/HomePage/home.php");
}

if (isset($_GET["like"])) {
    $id = $_GET["like"];
    include '../dbconnection.php';
    $getLikes = "SELECT * FROM articles where `articles`.`id` = $id";
    $likes = $connection->query($getLikes);
    $total_likes = 0;
    if ($likes->num_rows > 0) {
        while ($row = $likes->fetch_assoc()) {
            $total_likes = $row["likes"] + 1;
        }
        $sql = "UPDATE `articles` SET `likes` = $total_likes  WHERE `articles`.`id` = $id";
        $result1 = $connection->query($sql);
        if ($result1) {
            $result2 = $connection->query("INSERT INTO `likes` (`id`, `user`, `article`) VALUES (NULL," . $_SESSION['id'] . ", $id)");
            if ($result2) {
                header("Location: /content/HomePage/home.php");
            }
        }
    }
    echo 'Error';
}

if (isset($_GET["dislike"])) {
    $id = $_GET["dislike"];
    include '../dbconnection.php';
    $getLikes = "SELECT * FROM articles where `articles`.`id` = $id";
    $likes = $connection->query($getLikes);
    $total_likes = 0;
    if ($likes->num_rows > 0) {
        while ($row = $likes->fetch_assoc()) {
            $total_likes = $row["likes"] - 1;
        }
        $sql = "UPDATE `articles` SET `likes` = $total_likes  WHERE `articles`.`id` = $id";
        $result1 = $connection->query($sql);
        if ($result1) {
            $result2 = $connection->query("DELETE FROM `likes` WHERE `likes`.`user` = " . $_SESSION['id'] . " AND `likes`.`article` = $id");
            if ($result2) {
                header("Location: /content/HomePage/home.php");
            }
        }
    }
    echo 'Error';
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class = 'article-card'>";
        echo "<h2>" . $row["title"] . "</h2>";
        echo "<div class = 'article-desc'>" . $row["wrte"] . "</div>";
        echo "<a href = '/content/article.php?id=" . $row["id"] . "'><img class = 'article-img' src = '" . $row["imgsrc"] . "'></a>";
        echo "<div class = 'article-actions'>";
        echo "<div class = 'heart-img'>";
        $likes = $connection->query("SELECT * FROM likes WHERE `likes`.`article` = " . $row['id']);
        $user_liked = false;
        while ($likes_row = $likes->fetch_assoc()) {
            if ($likes_row['user'] === $_SESSION['id']) {
                echo "<a class = 'delete-img' href = '/content/HomePage/home.php?dislike=" . $row["id"] . "'>
<img src = './images/heart-filled.svg'>
</a>";
                $user_liked = true;
                break;
            }
        }
        if (!$user_liked) {
            echo "<a class = 'delete-img' href = '/content/HomePage/home.php?like=" . $row["id"] . "'>
<img src = './images/heart.svg'>
</a>";
        }
        echo "<span>" . $row['likes'] . "</span>";
        echo "</div>";
        if ($_SESSION["user"] == "admin") {
            echo "<a class = 'delete-img' href = '/content/HomePage/home.php?delete=" . $row["id"] . "' >
<img src = './images/delete.svg'>
</a>";
        }
        echo "</div>";
        echo "</div>";
    }
}

echo "

</body>

</html>";
